Use an Arduino as a ROS publisher/subscriber

Works with http://wiki.ros.org/rosserial, requires a rosserial node to connect
