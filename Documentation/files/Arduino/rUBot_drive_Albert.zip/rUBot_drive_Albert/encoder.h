#ifndef _ENCODER_H_
#define _ENCODER_H_
#include"config.h"
#include <Encoder.h>
//Encoder *encD=new Encoder(18, 31);
//Encoder *encC=new Encoder(19, 38);//rev
//Encoder *encB=new Encoder(3, 49);
//Encoder *encA=new Encoder(2,23);//rev

//Encoder *encD=new Encoder(2, 23);
Encoder *encD=new Encoder(2, A1);
Encoder *encC=new Encoder(3, 49);//rev
Encoder *encB=new Encoder(19, 38);
Encoder *encA=new Encoder(18,31);//rev




#endif
